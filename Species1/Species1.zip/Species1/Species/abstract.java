package Species;    //En este apartado creo una carpeta con el nombre Species el cual me archivara todas las clases a excepcion del Main.
abstract class LivingBeing{     //Utilizo esta clase ya que se encuentra por encima de animales ya que son seres vivos, el cual lo extiendo desde animales y lo implemento en difine.
    
    abstract void beBorn();     //Es importante saber que los abstract no pueden definir un cuerpo.
    
}
