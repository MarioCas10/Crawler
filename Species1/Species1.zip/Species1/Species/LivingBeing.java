package Species;
public abstract class LivingBeing {
    abstract void beBorn();
}
