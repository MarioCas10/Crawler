package Species;            //En este apartado creo una carpeta con el nombre Species el cual me archivara todas las clases a excepcion del Main.
public interface Define{    //En el define solo se pueden ya que es tipo interface solo se ultiza para metodos, no te deja construir objetos dentro de la misma.

    public void define();   //Ya que que una clase no puede heredar de una de dos o mas super clases, pero si puede impletar multiples interfaces.
                               
}
